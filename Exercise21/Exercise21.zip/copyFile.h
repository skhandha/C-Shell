#ifndef COPYFILE_H
#define COPYFILE_H

/* Prototypes of provided functions */
void copyFile();
int openFile(const char *fileName, const char *mode);

#endif
